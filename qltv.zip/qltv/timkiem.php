<?php 


require_once("incfiles/head.php");
require_once("incfiles/connect.php");

?>

<div  class="container-fluid">

    <body >
        <div>
		<label for="inputMasv">Tìm kiếm</label>
            <form action="timkiem.php" method="get">
                Tên sách: <input type="text" name="search" />
                <input type="submit" name="ok" value="search" />
            </form>
        </div>

			    <tbody>
				
			    <?php 
				if (isset($_REQUEST['ok'])) 
        {
            $search = addslashes($_GET['search']);
 
            if (empty($search)) {
                echo "Yeu cau nhap du lieu vao o trong";
            } 
			else
				 $sql = "select * from dsbook where namebook like '%$search%' " ;
				 $query = mysqli_query($kn,$sql);
 
                // Đếm số đong trả về trong sql.
                $num = mysqli_num_rows($query);
 
                // Nếu có kết quả thì hiển thị, ngược lại thì thông báo không tìm thấy kết quả
                if ($num > 0 && $search != "") 
                {
                    // Dùng $num để đếm số dòng trả về.
                    echo "tên sách: <b>$search</b>";
 
                    echo '<table border="1" cellspacing="0" cellpadding="10">';
                    while ($row = mysqli_fetch_assoc($query)) {
                        echo '<tr>';
                            echo "<td>{$row['id']}</td>";
                            echo "<td>{$row['namebook']}</td>";
                            echo "<td>{$row['tacgia']}</td>";
                            echo "<td>{$row['theloai']}</td>";
							echo "<td>{$row['soluong']}</td>";
                        echo '</tr>';
                    }
                    echo '</table>';
                } 
                else {
                    echo "Khong tim thay ket qua!";
                }
            }
        
        ?>   
		
    </body>
</div>
 <?php require_once("incfiles/end.php"); ?> 