<?php 
	session_start();
	require_once("../incfiles/connect.php");
	$username =($_POST['username']);
    $password =($_POST['password']);
   
    
    
    if (!empty($username) && !empty($password))
    {
           
       $lenhsql="select*from account where username='".$username."' and password='".$password."'";
	   $kq=mysqli_query($kn,$lenhsql)or die (" không truy vấn được");
        if ($kq==0)
            echo "<b>Tên đăng nhập hoặc mật khẩu không đúng !</b>";
        else {
            $query = mysqli_query("select * from account where username = '".$username."' and password = '".$password."'");
            $_SESSION["username"] = $username;
          

            echo'<b>Đăng nhập thành công. ';
            echo'<script type="text/javascript">
            alert("Đăng nhập thành công");
          window.location="/qltv";
        </script>';
        }

    }
    else
        echo'<b>Vui lòng nhập đầy đủ thông tin</b>';
?>