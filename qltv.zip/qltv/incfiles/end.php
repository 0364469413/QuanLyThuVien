<footer class="text-center">
        <div class="footer-above">
            <div class="container">
                <div class="row">
                    <div class="footer-col col-md-4">
                        <h3>Địa chỉ</h3>
                        <p>Trường Đại Học Quy Nhơn
                            <br>170 An Dương Vương-TP. Quy Nhơn</p>
                    </div>
                    <div class="footer-col col-md-4">
                        <h3>Theo dõi Trên Mạng Xã Hội</h3>
                        <ul class="list-inline">
                            <li>
                                <a href="http://facebook.com/tnit97" class="btn-social btn-outline"><i class="fa fa-fw fa-facebook"></i></a>
                            </li>
                            <li>
                                <a href="https://plus.google.com/113033670997906755955" class="btn-social btn-outline"><i class="fa fa-fw fa-google-plus"></i></a>
                            </li>
                            
                            <li>
                                <a href="http://thanhtrungit.com" class="btn-social btn-outline"><i class="fa fa-fw fa-dribbble"></i></a>
                            </li>
                        </ul>
                    </div>
                    <div class="footer-col col-md-4">
                        <h3>Tác Giả</h3>
                        <p>Quang Trường - Võ Hằng - Trường Đại Học Quy Nhơn </p>
                        <p>Lập trình viên - Trường Hằng Vũ </p>
                        <p> Website: <a href="http://quangtruongvohang.com">TruongHangVuIT.Com</a> </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-below">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        Copyright &copy; 2021 
                    </div>
                </div>
            </div>
        </div>
    </footer>