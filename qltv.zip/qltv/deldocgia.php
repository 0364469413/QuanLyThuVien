<?php 
require_once("incfiles/connect.php");
$id= $_GET['id']; 
$sq="DELETE FROM dsdocgia where masv=".$id."";

$query= mysqli_query($kn,$sq);
if ($query)
	echo'Đã xóa
		<script type="text/javascript">
		  window.location="/qltv/qldocgia.php";
		</script>';
else 
	echo'Lỗi';
?>