<?php
require_once("incfiles/connect.php");

$id= $_POST['idbook'];
$name = $_POST['tensach`'];
$sl = $_POST['soluong'];
$tacgia = $_POST['tacgia'];
$theloai = $_POST['theloai'];
if (empty($name) || empty($sl) || empty($tacgia) || empty($theloai))
//if (empty($name))
	echo'Không bỏ trống các trường giá trị';
else 
	{
		$update="UPDATE dsbook SET  (tensach,soluong,tacgia,theloai) values ('.$name.',.$sl.,'.$tacgia.','.$theloai.')";
		
		$result = mysqli_query($kn,$update);
		if ($result)
		{
			echo'
			<div class="alert alert-info alert-dismissible">
			  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			  <strong>Thông Báo!</strong> Chỉnh sửa thành công.
			</div>
				 
		';
		}
		else 
		echo'Thất bại';
	}

?>