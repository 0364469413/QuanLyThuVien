<?php 


require_once("incfiles/head.php");

?>
<br>
<script type="text/javascript">

  function reload(){
  	window.location.reload();
  }
function addtype(){
		$('#loadaddtype').html('<i class="fa fa-spinner fa-pulse fa-fw"></i> Đang kiểm tra');
		setTimeout(function(){
			$('#check').load('addtype.php',$('#form-addtype').serializeArray());
			$('#loadaddtype').html('<i class="fa fa-check-square-o" aria-hidden="true"></i> Thêm');
		},1000);
    	
    }
function addbook(){
		$('#loadaddbook').html('<i class="fa fa-spinner fa-pulse fa-fw"></i> Đang kiểm tra');
		setTimeout(function(){
			$('#check2').load('addbook.php',$('#form-addbook').serializeArray());
			$('#loadaddbook').html('<i class="fa fa-check-square-o" aria-hidden="true"></i> Thêm');
		},1000);
    	
    }
    
function edittype(id){
		console.log(id);
		
		$('#loadedittype'+id).html('<i class="fa fa-spinner fa-pulse fa-fw"></i> Đang kiểm tra');
		setTimeout(function(){
		$('#check'+id).load('edittype.php',$('#form-edittype'+id).serializeArray());
		$('#loadedittype'+id).html('<i class="fa fa-check-square-o" aria-hidden="true"></i> Save');
		},1000);
		
    	
    }
   

</script>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Thêm độc giả</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Le styles -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <style type="text/css">
      body {
        padding-top: 40px;
        padding-bottom: 40px;
        background-color: #f5f5f5;
      }

      .form-signin {
        max-width: 300px;
        padding: 19px 29px 29px;
        margin: 0 auto 20px;
        background-color: #fff;
        border: 1px solid #e5e5e5;
        -webkit-border-radius: 5px;
           -moz-border-radius: 5px;
                border-radius: 5px;
        -webkit-box-shadow: 0 1px 2px rgba(0,0,0,.05);
           -moz-box-shadow: 0 1px 2px rgba(0,0,0,.05);
                box-shadow: 0 1px 2px rgba(0,0,0,.05);
      }
      .form-signin .form-signin-heading,
      .form-signin .checkbox {
        margin-bottom: 10px;
      }
      .form-signin input[type="text"],
      .form-signin input[type="password"] {
        font-size: 16px;
        height: auto;
        margin-bottom: 15px;
        padding: 7px 9px;
      }
	  .form-signin .warning {
	    font-size: 14px;
		color: red; 
		margin-top: 8px;
		text-align: center;
	  }

    </style>
    <link href="css/bootstrap-responsive.css" rel="stylesheet">

    <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
    <![endif]-->

    <!-- Fav and touch icons -->
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="ico/apple-touch-icon-114-precomposed.png">
      <link rel="apple-touch-icon-precomposed" sizes="72x72" href="ico/apple-touch-icon-72-precomposed.png">
                    <link rel="apple-touch-icon-precomposed" href="ico/apple-touch-icon-57-precomposed.png">
                                   <link rel="shortcut icon" href="ico/favicon.png">
  </head>
<body style="background-color:#18BC9C">
        <div class="container">
		
        			<form  class="form-signin" style="background-color:#18BC9C;color:Black" method="POST" action="xulythemdocgia.php">
					 <center>
					 <h2 style="color:White" class="form-signin-heading">THÊM ĐỘC GIẢ</h2>

							<label for="inputMasv">Mã độc giả</label>
        					<input type="text" name="masv" class="input-block-level"  placeholder="Mã độc giả" required="required" autofocus="autofocus">



							<label for="inputTensv">Họ và tên</label>
        						<input type="text" name="hoten" class="input-block-level"  placeholder="Họ và tên" required="required">



							<label for="inputNgaysinh">Ngày sinh</label>
        						<input type="date" name="ngaysinh"  class="input-block-level"  placeholder="Ngày sinh" required="required">
        						

        					<div class="radio">
        						<label>
        							<input type="radio" name="gioitinh" value="Nam" checked>
        							Nam
        						</label>
        						<label>
        							<input type="radio" name="gioitinh" value="Nữ">
        							Nữ
        						</label>
        					</div>

						
						<label for="inputNoisinh">Nơi sinh</label>
        					<input type="text" name="noisinh" id="inputNoisinh" class="input-block-level"  placeholder="Nơi sinh" required="required">
						


        				<input style="background-color:#5bc0de;color:White" class="btn btn-large btn-primary" type="submit" name="Add"  value="Thêm">
        			</center>
					</form>
		
        </div>
		</body>
 <?php require_once("incfiles/end.php"); ?> 


