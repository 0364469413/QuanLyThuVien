<meta charset="utf8">
<?php
session_start();
require_once("incfiles/connect.php");
header('Content-Type: text/html; charset=UTF-8');
if (isset($_POST['Add'])) 
{
	$masv = ($_POST['masv']);
	$hoten = ($_POST['hoten']);
	$ngaysinh = ($_POST['ngaysinh']);
	$gioitinh = ($_POST['gioitinh']);
	$noisinh = ($_POST['noisinh']);



		
		$sql="select * from dsdocgia where  masv='$masv'";
		//thực hiện câu truy vấn trên biến keetsnoois $conn
		$kt=mysqli_query($kn, $sql);
		//kiểm tra tài khoản đã tồn tại hay chưa
		if(mysqli_num_rows($kt)  > 0){
			echo "<script>alert('Độc giả đã tồn tại')</script>";
			exit;
		}
		$sql="INSERT INTO dsdocgia(masv,hoten,ngaysinh,gioitinh,noisinh) VALUES ('$masv','$hoten','$ngaysinh','$gioitinh','$noisinh')";
		$query = mysqli_query($kn,$sql);
		if($query)
		{
			echo "<script>alert('Thêm độc giả thành công')</script>";
		}
		else 
			echo 'Lỗi query';
	
}

?>
