<?php 
require_once("incfiles/connect.php");
$id= $_GET['idbook']; 
$idtype= $_GET['idtype']; 

$dt="DELETE FROM dsbook where IDbook=".$id."";
$query= mysqli_query($kn,$dt);
if ($query)
	echo'Đã xóa
		<script type="text/javascript">
		  window.location="viewlistbook.php?id='.$idtype.'"
		</script>';
else 
	echo'Lỗi';
?>