<meta charset="utf8">
<?php
session_start();
require_once("incfiles/connect.php");
header('Content-Type: text/html; charset=UTF-8');
if (isset($_POST['themsach'])) 
{
	$namebook = ($_POST['namebook']);
	$tacgia = ($_POST['tacgia']);
	$theloai = ($_POST['theloai']);
	$soluong = ($_POST['soluong']);

		//kiểm tra các thông tin đã nhập đủ chưa
	if(!$namebook || !$tacgia || !$soluong)
	{
			echo "<script>alert('Chưa nhập đầy đủ thông tin')</script>";
		    exit;
		
	}
	else
	{
		$sql="select * from dsbook where namebook='$namebook'";
		//thực hiện câu truy vấn trên biến keetsnoois $conn
		$kt=mysqli_query($kn, $sql);
		//kiểm tra sách đã tồn tại hay chưa
		if(mysqli_num_rows($kt)  > 0){
			echo "<script>alert('Sách đã tồn tại')</script>";
			exit;
		}
		$sql="INSERT INTO dsbook(namebook,tacgia,theloai,soluong) VALUES ('$namebook','$tacgia','$theloai','$soluong')";
		$query = mysqli_query($kn,$sql);
		if($query)
		{
		echo "<script>alert('Thêm sách thành công')</script>";
		}
		else 
		echo'Lỗi query';
	}
}

?>
