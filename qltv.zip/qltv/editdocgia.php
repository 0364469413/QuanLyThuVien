<?php
require_once("incfiles/connect.php");

$masv= $_POST['masv'];
$hoten= $_POST['hoten'];

if (empty($hoten))
	echo'Không bỏ trống các trường giá trị';
else 
	{
		$update="UPDATE dsdocgia SET hoten= '".$hoten."' where masv = '".$masv."' ";
		$result = mysqli_query($kn,$update);
		if ($result)
		{
			echo'
			<div class="alert alert-info alert-dismissible">
			  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			  <strong>Thông Báo!</strong> Chỉnh sửa thành công.
			</div>
				 
		';
		}
		else 
		echo'Thất bại';
	}

?>