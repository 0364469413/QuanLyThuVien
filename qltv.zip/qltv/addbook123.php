<div class="col-md-3">
			<div class="panel panel-primary">
				  <div class="panel-heading">Thêm Sách</div>
				  <div class="panel-body">
				  <form action="addbook.php" id="form-addbook" method="POST">
				  		<div class="form-group">
						    <div class="input-group">
						      <div class="input-group-addon">Tên sách</div>
						      <input type="text" name="tensach" class="form-control" id="exampleInputAmount" placeholder="">
						    </div>
						</div>
						<div class="form-group">
						    <div class="input-group">
						      <div class="input-group-addon">Tác giả</div>
						      <input type="text" name="soluong" class="form-control" id="exampleInputAmount" placeholder="">
						    </div>
						</div>
						<div class="form-group">
						    <div class="input-group">
						      <div class="input-group-addon">Thể loại</div>
						      <input type="text" name="tacgia" class="form-control" id="exampleInputAmount" placeholder="">
						    </div>
						</div>
						<div class="form-group">
						    <div class="input-group">
						      <div class="input-group-addon">Số lượng</div>
						      <input type="text" name="theloai" class="form-control" id="exampleInputAmount" placeholder="">
						    </div>
						</div>
						
					</form>
					<center>
						<button onclick="themsach();" name="btn-reg" class="btn btn-info"> Thêm Sách </div> </button><br>
						<font color="red" id="check2"></font>
						</center>
				  </div>