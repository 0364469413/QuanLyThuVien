
<?php 
require_once("incfiles/head.php");
$nametype= $_GET['name'];


?>
<br>
<script type="text/javascript">
	function reload(){
	  	window.location.reload();
	  }
	function editbook(id){
		
		
		$('#loadeditbook'+id).html('<i class="fa fa-spinner fa-pulse fa-fw"></i> Đang kiểm tra');
		setTimeout(function(){
		$('#check'+id).load('editbook.php',$('#form-editbook'+id).serializeArray());
		$('#loadeditbook'+id).html('<i class="fa fa-check-square-o" aria-hidden="true"></i> Save');
		},1000);
		
    	
    }
    function addbook(){
		$('#loadaddbook').html('<i class="fa fa-spinner fa-pulse fa-fw"></i> Đang kiểm tra');
		setTimeout(function(){
			$('#check2').load('addbook.php',$('#form-addbook').serializeArray());
			$('#loadaddbook').html('<i class="fa fa-check-square-o" aria-hidden="true"></i> Thêm');
		},1000);
    	
    }
</script>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-9">
<?php 
$aad="select * from theloai where name=".$nametype."";
$title = mysqli_query($kn,$aad);
$title2 = mysqli_fetch_array($title);
?>
<button class="btn btn-success">Danh Mục: <?php echo $title2['name']; ?> </button></a>
			<table class="table table-hover">
			    <thead>
			      <tr>
			        <th>ID</th>
			        <th>Tên sách</th>
			       	<th>Tác giả</th>
			        <th>Số lượng</th>
			        
			      </tr>
			    </thead>

			    <tbody>
			    <?php 
				$tb="select * from dsbook where namebook=".$nametype."";
				
				
			    	$kq = mysqli_query($kn,$tb);
			    	while ($row = mysqli_fetch_array($kq))
			    	{
			    		?>
			     <tr>
			        <td><?php echo $row['id']; ?></td>
			        <td><?php echo $row['namebook']; ?></td>
			       	<td><?php echo $row['tacgia']; ?></td>
			        <td><?php echo $row['soluong']; ?></td>

			        <td>
			        
			        
					<!-- end Modal chỉnh sửa -->
					</td>
			      </tr>
			     <?php } ?>
			      
			    </tbody>
			</table>
<a href="/qltv"> <button class="btn btn-success">Về Trang Chủ</button></a>
	
		<!--End  Right col -->
	</div>

</div>


</body>
</html>